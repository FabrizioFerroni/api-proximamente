<!DOCTYPE html>
<html lang="es">
<head>
    
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<title><?php echo $__env->yieldContent('tt'); ?> | Fabrizio DEV</title>
	
	<link rel="shortcut icon" href="<?php echo e(url('static/img/favicon.ico')); ?>" type="image/x-icon">
	
	
	<link rel="stylesheet" href="<?php echo e(url('static/css/app.css?v='.time())); ?>">
	
	<script src="https://kit.fontawesome.com/7391b45a61.js" crossorigin="anonymous"></script>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body style="margin: 0px; padding: 0px; background-color: #f3f3f3;">
    <div class="main" style="width: 60%; max-width: 728px; margin: 0 auto; display: block;">
        <img src="https://i.imgur.com/4T3YrZw.png" class="img-banner" style="width: 100%; display: block;">
        
        <div class="content" style="background-color: #fff; padding: 24px;">
            
            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-jwt\resources\views/mails/master.blade.php ENDPATH**/ ?>