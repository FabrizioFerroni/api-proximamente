<?php $__env->startSection('tt'); ?>
    Lo siento
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<p>Hola, <strong> <?php echo e($nombre); ?> </strong></p>
<p>
    Lo siento mucho por hacerte spam con mis noticias.
    Prometo que no te va a llegar ningun mail mas.
</p>
<p>
    Tus datos con lo cual te habias subscripto son:
    <br>
    <br>
    <strong>Correo Electrónico:</strong> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>, <br>
    <strong>Fecha de subcripcion:</strong> <?php echo e($fecha_sub); ?>, <br>
    <strong>Fecha de baja subcripción:</strong> <?php echo e($fecha_baja); ?>

</p>

<p>Gracias por confiar en Fabrizio DEV</p>
<p style="font-size: 13px">
    Si seguis recibiendo correos por favor ponte en contacto conmigo. <a href="mailto:info@fabriziodev.ar" target="_blank" style="text-decoration: none; color:#FF3030; ">info@fabriziodev.ar</a>. Gracias
</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mails.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-jwt\resources\views/mails/baja.blade.php ENDPATH**/ ?>