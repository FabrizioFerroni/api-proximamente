<?php $__env->startSection('tt'); ?>
    Bienvenido a mi portfolio
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<p>Hola, <strong> <?php echo e($nombre); ?> </strong></p>
<p>
    Gracias por subcribirte en mi portfolio web.
    Te mantendre informado de los proximos avances del desarrollo.
</p>
<p>
    Tus datos con lo cual te registraste son:
    <br>
    <br>
    <strong>Correo Electrónico:</strong> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>, <br>
    <strong>Fecha de subcripcion:</strong> <?php echo e($fecha_sub); ?>

</p>
<div class="center" style="display: flex; justify-content: center; align-items: center;">
    <p><a href="https://adelanto.fabriziodev.ar" target="_blank" class="miboton" style=" background-color: #FF3030; display: inline-block; color: #fff; padding: 12px; border-radius: 8px; text-decoration: none;">Ir a mi ver un adelanto de mi portfolio</a></p>
</div>
<p>Gracias por confiar en Fabrizio DEV</p>
<p style="font-size: 13px">
    Si no quiere recibir mas correos con los adelantos puede hacer <a href="http://localhost:4200/darse-de-baja/<?php echo e($email); ?>" target="_blank" style="text-decoration: none; color:#FF3030; ">click aquí</a>
</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mails.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-jwt\resources\views/mails/welcome.blade.php ENDPATH**/ ?>